/* ═══════════════════════════════════════════
   PORTFOLIO — app.js
   Handles: API fetching, project rendering,
   filtering, modal, contact form, animations
   ═══════════════════════════════════════════ */

const API_BASE = '/api';

// ── Cached project data ──────────────────────
let allProjects = [];
let activeFilter = 'all';

// ── DOM refs ─────────────────────────────────
const projectsGrid  = document.getElementById('projectsGrid');
const filterBtns    = document.querySelectorAll('.filter-btn');
const modalOverlay  = document.getElementById('modalOverlay');
const modalClose    = document.getElementById('modalClose');
const modalContent  = document.getElementById('modalContent');
const contactForm   = document.getElementById('contactForm');
const formFeedback  = document.getElementById('formFeedback');
const nav           = document.getElementById('nav');
const navToggle     = document.getElementById('navToggle');

// ── Category emoji map ───────────────────────
const categoryEmoji = {
  'Full Stack':       '🛠',
  'Machine Learning': '🤖',
  'Mobile':           '📱',
  'Open Source':      '⭐',
  'DevOps':           '⚙',
  'default':          '💻'
};

// ═══════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  fetchProjects();
  initNav();
  initFilters();
  initModal();
  initContactForm();
  initAnimations();
  animateCounters();
});

// ═══════════════════════════════════════════
// FETCH PROJECTS
// ═══════════════════════════════════════════
async function fetchProjects() {
  try {
    const res  = await fetch(`${API_BASE}/projects`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    allProjects = json.data || [];
    renderProjects(allProjects);
  } catch (err) {
    console.error('Failed to load projects:', err);
    renderError();
  }
}

// ═══════════════════════════════════════════
// RENDER PROJECTS
// ═══════════════════════════════════════════
function renderProjects(projects) {
  if (!projects.length) {
    projectsGrid.innerHTML = `<div class="projects-loading"><p>No projects found.</p></div>`;
    return;
  }

  projectsGrid.innerHTML = projects.map((p, i) => buildCard(p, i)).join('');

  // Bind card click → modal
  projectsGrid.querySelectorAll('.project-card').forEach(card => {
    card.addEventListener('click', (e) => {
      if (e.target.closest('a')) return; // let links through
      const id = card.dataset.id;
      const project = allProjects.find(p => String(p.id) === id);
      if (project) openModal(project);
    });
  });
}

function buildCard(p, i) {
  const emoji = categoryEmoji[p.category] || categoryEmoji.default;
  const stackHtml = (p.tech_stack || []).slice(0, 4).map(t =>
    `<span class="tag">${t}</span>`
  ).join('');

  return `
    <article class="project-card fade-in ${p.featured ? 'featured' : ''}"
             data-id="${p.id}"
             data-category="${p.category || ''}"
             style="transition-delay:${i * 60}ms">
      ${p.featured ? `<div class="project-featured-badge">Featured</div>` : ''}
      ${p.image_url
        ? `<img class="project-img" src="${p.image_url}" alt="${p.title}" loading="lazy" />`
        : `<div class="project-img-placeholder">${emoji}</div>`
      }
      <div class="project-body">
        <p class="project-category">${p.category || 'Project'}</p>
        <h3 class="project-title">${p.title}</h3>
        <p class="project-desc">${p.description || ''}</p>
        <div class="project-stack">${stackHtml}</div>
        <div class="project-actions" onclick="event.stopPropagation()">
          ${p.live_url ? `<a href="${p.live_url}" target="_blank" class="project-btn project-btn-primary">Live demo ↗</a>` : ''}
          ${p.github_url ? `<a href="${p.github_url}" target="_blank" class="project-btn project-btn-ghost">GitHub ↗</a>` : ''}
        </div>
      </div>
    </article>
  `;
}

function renderError() {
  projectsGrid.innerHTML = `
    <div class="projects-loading" style="grid-column:1/-1">
      <p style="color:var(--error)">Couldn't load projects. Is the backend running?</p>
      <button class="btn btn-outline" onclick="fetchProjects()">Retry</button>
    </div>
  `;
}

// ═══════════════════════════════════════════
// FILTER
// ═══════════════════════════════════════════
function initFilters() {
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      activeFilter = btn.dataset.filter;
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filtered = activeFilter === 'all'
        ? allProjects
        : allProjects.filter(p => p.category === activeFilter);
      renderProjects(filtered);
      // Trigger animation for new cards
      requestAnimationFrame(() => {
        document.querySelectorAll('.project-card.fade-in').forEach(el => {
          el.classList.add('visible');
        });
      });
    });
  });
}

// ═══════════════════════════════════════════
// MODAL
// ═══════════════════════════════════════════
function initModal() {
  modalClose.addEventListener('click', closeModal);
  modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });
}

function openModal(p) {
  const stackHtml = (p.tech_stack || []).map(t =>
    `<span class="tag">${t}</span>`
  ).join('');

  modalContent.innerHTML = `
    ${p.image_url
      ? `<img class="modal-img" src="${p.image_url}" alt="${p.title}" loading="lazy" />`
      : `<div class="modal-img" style="background:var(--accent-dim);display:flex;align-items:center;justify-content:center;font-size:72px">${categoryEmoji[p.category] || '💻'}</div>`
    }
    <p class="modal-meta">${p.category || 'Project'}</p>
    <h2 class="modal-title">${p.title}</h2>
    <p class="modal-desc">${p.long_description || p.description || ''}</p>
    <div class="modal-stack">${stackHtml}</div>
    <div class="modal-actions">
      ${p.live_url ? `<a href="${p.live_url}" target="_blank" class="btn btn-primary">View live ↗</a>` : ''}
      ${p.github_url ? `<a href="${p.github_url}" target="_blank" class="btn btn-ghost">GitHub ↗</a>` : ''}
    </div>
  `;
  modalOverlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  modalOverlay.classList.remove('open');
  document.body.style.overflow = '';
}

// ═══════════════════════════════════════════
// CONTACT FORM
// ═══════════════════════════════════════════
function initContactForm() {
  if (!contactForm) return;

  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = document.getElementById('submitBtn');
    const btnText = submitBtn.querySelector('.btn-text');
    const btnLoading = submitBtn.querySelector('.btn-loading');

    // Clear previous feedback
    formFeedback.className = 'form-feedback';
    formFeedback.textContent = '';

    // Gather data
    const data = {
      name:    document.getElementById('name').value.trim(),
      email:   document.getElementById('email').value.trim(),
      subject: document.getElementById('subject').value.trim(),
      message: document.getElementById('message').value.trim()
    };

    // Basic client-side validation
    if (!data.name || !data.email || !data.message) {
      showFormFeedback('error', 'Please fill in all required fields.');
      return;
    }

    // Loading state
    submitBtn.disabled = true;
    btnText.style.display = 'none';
    btnLoading.style.display = 'inline';

    try {
      const res  = await fetch(`${API_BASE}/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const json = await res.json();

      if (json.success) {
        showFormFeedback('success', json.message || 'Message sent! I\'ll be in touch soon.');
        contactForm.reset();
      } else {
        const errMsg = json.errors ? json.errors.join(' · ') : json.error;
        showFormFeedback('error', errMsg || 'Something went wrong. Please try again.');
      }
    } catch (err) {
      showFormFeedback('error', 'Could not send message. Please email me directly.');
    } finally {
      submitBtn.disabled = false;
      btnText.style.display = 'inline';
      btnLoading.style.display = 'none';
    }
  });
}

function showFormFeedback(type, msg) {
  formFeedback.className = `form-feedback ${type}`;
  formFeedback.textContent = msg;
  formFeedback.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// ═══════════════════════════════════════════
// NAV
// ═══════════════════════════════════════════
function initNav() {
  // Sticky shadow on scroll
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 40);
  }, { passive: true });

  // Mobile toggle
  navToggle.addEventListener('click', () => {
    nav.classList.toggle('mobile-open');
  });

  // Close mobile nav on link click
  nav.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => nav.classList.remove('mobile-open'));
  });
}

// ═══════════════════════════════════════════
// INTERSECTION OBSERVER — fade-in
// ═══════════════════════════════════════════
function initAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  // Observe static elements
  document.querySelectorAll('.about-grid, .skill-group, .timeline-item, .contact-grid').forEach(el => {
    el.classList.add('fade-in');
    observer.observe(el);
  });

  // Re-observe dynamic project cards whenever grid changes
  const gridObserver = new MutationObserver(() => {
    document.querySelectorAll('.project-card.fade-in:not(.visible)').forEach(el => {
      observer.observe(el);
    });
  });
  if (projectsGrid) {
    gridObserver.observe(projectsGrid, { childList: true });
  }
}

// ═══════════════════════════════════════════
// COUNTER ANIMATION
// ═══════════════════════════════════════════
function animateCounters() {
  const counters = document.querySelectorAll('.stat-num[data-target]');
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el     = entry.target;
      const target = parseInt(el.dataset.target, 10);
      const duration = 1400;
      const start    = performance.now();

      function update(now) {
        const elapsed = now - start;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.round(eased * target);
        if (progress < 1) requestAnimationFrame(update);
        else el.textContent = target;
      }
      requestAnimationFrame(update);
      counterObserver.unobserve(el);
    });
  }, { threshold: 0.5 });

  counters.forEach(el => counterObserver.observe(el));
}
