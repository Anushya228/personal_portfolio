/**
 * Database Configuration
 * Supports: SQLite (default/dev), PostgreSQL, MySQL, MongoDB
 * Set DB_TYPE in .env: 'sqlite' | 'postgres' | 'mysql' | 'mongodb'
 */

const DB_TYPE = process.env.DB_TYPE || 'sqlite';

let db = null;
let dbType = DB_TYPE;

// ---------- SQLite (default, zero-config) ----------
async function initSQLite() {
  const Database = require('better-sqlite3');
  const dbPath = process.env.SQLITE_PATH || './portfolio.db';
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');

  db.exec(`
    CREATE TABLE IF NOT EXISTS projects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      long_description TEXT,
      tech_stack TEXT,
      image_url TEXT,
      live_url TEXT,
      github_url TEXT,
      featured INTEGER DEFAULT 0,
      category TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      subject TEXT,
      message TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Seed demo data if empty
  const count = db.prepare('SELECT COUNT(*) as cnt FROM projects').get();
  if (count.cnt === 0) {
    seedProjects();
  }

  console.log('✅ SQLite database ready');
  return db;
}

// ---------- PostgreSQL ----------
async function initPostgres() {
  const { Pool } = require('pg');
  const pool = new Pool({
    host: process.env.PG_HOST || 'localhost',
    port: process.env.PG_PORT || 5432,
    database: process.env.PG_DATABASE || 'portfolio',
    user: process.env.PG_USER || 'postgres',
    password: process.env.PG_PASSWORD || '',
    ssl: process.env.PG_SSL === 'true' ? { rejectUnauthorized: false } : false
  });

  await pool.query(`
    CREATE TABLE IF NOT EXISTS projects (
      id SERIAL PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      long_description TEXT,
      tech_stack TEXT,
      image_url TEXT,
      live_url TEXT,
      github_url TEXT,
      featured BOOLEAN DEFAULT false,
      category VARCHAR(100),
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS contacts (
      id SERIAL PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) NOT NULL,
      subject VARCHAR(255),
      message TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT NOW()
    );
  `);

  db = pool;
  console.log('✅ PostgreSQL database ready');
  return pool;
}

// ---------- MongoDB ----------
async function initMongoDB() {
  const { MongoClient } = require('mongodb');
  const client = new MongoClient(process.env.MONGO_URI || 'mongodb://localhost:27017');
  await client.connect();
  db = client.db(process.env.MONGO_DB || 'portfolio');
  console.log('✅ MongoDB database ready');
  return db;
}

// ---------- Seed Data ----------
function seedProjects() {
  const projects = [
    {
      title: 'E-Commerce Platform',
      description: 'Full-stack shopping platform with cart, payments, and admin dashboard.',
      long_description: 'Built a complete e-commerce solution featuring product catalog, shopping cart, Stripe payments, order tracking, and a React-based admin dashboard. Handles 10,000+ products with Redis caching.',
      tech_stack: JSON.stringify(['React', 'Node.js', 'PostgreSQL', 'Redis', 'Stripe']),
      image_url: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&q=80',
      live_url: 'https://example.com',
      github_url: 'https://github.com',
      featured: 1,
      category: 'Full Stack'
    },
    {
      title: 'Real-Time Chat App',
      description: 'WebSocket-powered messaging with rooms, presence, and file sharing.',
      long_description: 'Scalable chat application using Socket.io for real-time messaging. Features include public/private rooms, user presence, typing indicators, file uploads via S3, and message history.',
      tech_stack: JSON.stringify(['Vue.js', 'Express', 'Socket.io', 'MongoDB', 'AWS S3']),
      image_url: 'https://images.unsplash.com/photo-1611746872915-64382b5c76da?w=800&q=80',
      live_url: 'https://example.com',
      github_url: 'https://github.com',
      featured: 1,
      category: 'Full Stack'
    },
    {
      title: 'ML Image Classifier',
      description: 'Deep learning model deployed as a REST API for image classification.',
      long_description: 'Trained a CNN on ImageNet using PyTorch achieving 94% top-5 accuracy. Deployed via FastAPI with a React frontend for drag-and-drop inference. Containerized with Docker.',
      tech_stack: JSON.stringify(['Python', 'PyTorch', 'FastAPI', 'React', 'Docker']),
      image_url: 'https://images.unsplash.com/photo-1677442135703-1787eea5ce01?w=800&q=80',
      live_url: 'https://example.com',
      github_url: 'https://github.com',
      featured: 1,
      category: 'Machine Learning'
    },
    {
      title: 'DevOps Dashboard',
      description: 'Kubernetes cluster monitoring with alerts, logs, and cost analytics.',
      long_description: 'Built a unified observability platform integrating Prometheus metrics, Grafana dashboards, and PagerDuty alerts. Tracks cluster health, pod status, and cloud spend.',
      tech_stack: JSON.stringify(['React', 'Go', 'Kubernetes', 'Prometheus', 'Grafana']),
      image_url: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&q=80',
      live_url: 'https://example.com',
      github_url: 'https://github.com',
      featured: 0,
      category: 'DevOps'
    },
    {
      title: 'Open Source CLI Tool',
      description: 'A developer productivity CLI with 2k+ GitHub stars.',
      long_description: 'Created a CLI tool that automates git workflows: smart branching, PR templates, commit linting, and changelog generation. Published to npm with full test coverage.',
      tech_stack: JSON.stringify(['Node.js', 'TypeScript', 'Jest', 'GitHub Actions']),
      image_url: 'https://images.unsplash.com/photo-1629654297299-c8506221ca97?w=800&q=80',
      live_url: 'https://npmjs.com',
      github_url: 'https://github.com',
      featured: 0,
      category: 'Open Source'
    },
    {
      title: 'Mobile Finance Tracker',
      description: 'React Native app for expense tracking with AI-powered categorization.',
      long_description: 'Cross-platform mobile app for personal finance. Connects to bank APIs via Plaid, auto-categorizes transactions using a fine-tuned classifier, and generates monthly spending reports.',
      tech_stack: JSON.stringify(['React Native', 'Expo', 'Python', 'Plaid API', 'SQLite']),
      image_url: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800&q=80',
      live_url: 'https://example.com',
      github_url: 'https://github.com',
      featured: 0,
      category: 'Mobile'
    }
  ];

  const stmt = db.prepare(`
    INSERT INTO projects (title, description, long_description, tech_stack, image_url, live_url, github_url, featured, category)
    VALUES (@title, @description, @long_description, @tech_stack, @image_url, @live_url, @github_url, @featured, @category)
  `);

  const insert = db.transaction((items) => {
    for (const item of items) stmt.run(item);
  });

  insert(projects);
  console.log('🌱 Seeded demo projects');
}

// ---------- Unified Query Layer ----------
const queries = {
  // Normalize results across DB types
  async getAllProjects() {
    if (dbType === 'mongodb') {
      return await db.collection('projects').find({}).sort({ featured: -1, created_at: -1 }).toArray();
    } else if (dbType === 'postgres') {
      const res = await db.query('SELECT * FROM projects ORDER BY featured DESC, created_at DESC');
      return res.rows;
    } else {
      return db.prepare('SELECT * FROM projects ORDER BY featured DESC, created_at DESC').all();
    }
  },

  async getProjectById(id) {
    if (dbType === 'mongodb') {
      const { ObjectId } = require('mongodb');
      return await db.collection('projects').findOne({ _id: new ObjectId(id) });
    } else if (dbType === 'postgres') {
      const res = await db.query('SELECT * FROM projects WHERE id = $1', [id]);
      return res.rows[0];
    } else {
      return db.prepare('SELECT * FROM projects WHERE id = ?').get(id);
    }
  },

  async getFeaturedProjects() {
    if (dbType === 'mongodb') {
      return await db.collection('projects').find({ featured: true }).toArray();
    } else if (dbType === 'postgres') {
      const res = await db.query('SELECT * FROM projects WHERE featured = true ORDER BY created_at DESC');
      return res.rows;
    } else {
      return db.prepare('SELECT * FROM projects WHERE featured = 1 ORDER BY created_at DESC').all();
    }
  },

  async saveContact(data) {
    const { name, email, subject, message } = data;
    if (dbType === 'mongodb') {
      return await db.collection('contacts').insertOne({ name, email, subject, message, created_at: new Date() });
    } else if (dbType === 'postgres') {
      await db.query('INSERT INTO contacts (name, email, subject, message) VALUES ($1,$2,$3,$4)', [name, email, subject, message]);
    } else {
      db.prepare('INSERT INTO contacts (name, email, subject, message) VALUES (?,?,?,?)').run(name, email, subject, message);
    }
  }
};

module.exports = {
  initialize: async () => {
    if (DB_TYPE === 'postgres') {
      await initPostgres();
    } else if (DB_TYPE === 'mongodb') {
      await initMongoDB();
    } else {
      await initSQLite();
    }
    dbType = DB_TYPE;
  },
  queries
};
