const express = require('express');
const router = express.Router();
const { queries } = require('../config/database');

// GET /api/projects — all projects
router.get('/', async (req, res) => {
  try {
    const projects = await queries.getAllProjects();
    const normalized = projects.map(normalizeProject);
    res.json({ success: true, data: normalized, count: normalized.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: 'Failed to fetch projects' });
  }
});

// GET /api/projects/featured
router.get('/featured', async (req, res) => {
  try {
    const projects = await queries.getFeaturedProjects();
    res.json({ success: true, data: projects.map(normalizeProject) });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to fetch featured projects' });
  }
});

// GET /api/projects/:id
router.get('/:id', async (req, res) => {
  try {
    const project = await queries.getProjectById(req.params.id);
    if (!project) return res.status(404).json({ success: false, error: 'Project not found' });
    res.json({ success: true, data: normalizeProject(project) });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to fetch project' });
  }
});

// Normalize tech_stack from JSON string to array
function normalizeProject(p) {
  return {
    ...p,
    tech_stack: typeof p.tech_stack === 'string'
      ? JSON.parse(p.tech_stack || '[]')
      : (p.tech_stack || []),
    featured: Boolean(p.featured)
  };
}

module.exports = router;
