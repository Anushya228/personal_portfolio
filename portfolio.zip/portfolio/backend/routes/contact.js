const express = require('express');
const router = express.Router();
const { queries } = require('../config/database');

// POST /api/contact
router.post('/', async (req, res) => {
  const { name, email, subject, message } = req.body;

  // Validation
  const errors = [];
  if (!name || name.trim().length < 2) errors.push('Name must be at least 2 characters');
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('Valid email is required');
  if (!message || message.trim().length < 10) errors.push('Message must be at least 10 characters');

  if (errors.length > 0) {
    return res.status(400).json({ success: false, errors });
  }

  try {
    await queries.saveContact({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      subject: subject?.trim() || 'No Subject',
      message: message.trim()
    });

    // If you have nodemailer configured:
    // await sendEmail({ name, email, subject, message });

    res.json({
      success: true,
      message: 'Message received! I\'ll get back to you within 24 hours.'
    });
  } catch (err) {
    console.error('Contact save error:', err);
    res.status(500).json({ success: false, error: 'Failed to send message. Please try again.' });
  }
});

module.exports = router;
