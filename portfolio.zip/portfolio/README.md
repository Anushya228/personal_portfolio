# 🚀 Personal Portfolio — Full Stack

A polished personal portfolio website with a Node.js/Express backend, multi-database support, and a clean dark UI.

![Stack](https://img.shields.io/badge/Frontend-HTML%2FCSS%2FJS-blueviolet)
![Stack](https://img.shields.io/badge/Backend-Node.js%20%2F%20Express-green)
![Stack](https://img.shields.io/badge/DB-SQLite%20%7C%20PostgreSQL%20%7C%20MongoDB-blue)

---

## ✨ Features

| Feature | Details |
|---|---|
| **REST API** | Express endpoints for projects & contact |
| **Multi-DB** | SQLite (zero-config), PostgreSQL, MySQL, MongoDB |
| **Auto-seed** | Demo projects seeded on first run |
| **Contact form** | Validated, saved to DB (+ optional email via nodemailer) |
| **Project modal** | Rich detail view with full descriptions |
| **Filter** | Client-side category filtering |
| **Animations** | Intersection Observer fade-ins + counter animation |
| **Responsive** | Mobile-first, works from 320px up |
| **Deploy-ready** | Configs for Vercel, Render, Railway, Heroku |

---

## 🏗 Project Structure

```
portfolio/
├── backend/
│   ├── server.js              # Express app entry point
│   ├── config/
│   │   └── database.js        # Multi-DB adapter (SQLite/PG/Mongo)
│   └── routes/
│       ├── projects.js        # GET /api/projects
│       └── contact.js         # POST /api/contact
├── frontend/
│   ├── index.html             # Single-page HTML
│   ├── css/style.css          # Full design system
│   └── js/app.js              # API calls, rendering, UI
├── .env.example               # Environment variables template
├── package.json
├── vercel.json                # Vercel deployment config
└── README.md
```

---

## ⚡ Quick Start (Local)

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env if needed — SQLite works with zero config
```

### 3. Run development server
```bash
npm run dev
# Backend: http://localhost:3001
# Open frontend/index.html in browser, or:
npm run dev:all   # runs both concurrently
```

### 4. Visit
Open `http://localhost:3001` — the backend serves the frontend automatically.

---

## 🗄 Database Options

### SQLite (default — no setup required)
```env
DB_TYPE=sqlite
SQLITE_PATH=./portfolio.db
```

### PostgreSQL
```bash
createdb portfolio
```
```env
DB_TYPE=postgres
PG_HOST=localhost
PG_DATABASE=portfolio
PG_USER=postgres
PG_PASSWORD=yourpassword
```

### MongoDB
```env
DB_TYPE=mongodb
MONGO_URI=mongodb://localhost:27017
MONGO_DB=portfolio
```

---

## 🌐 API Reference

### Projects
| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/projects` | All projects |
| `GET` | `/api/projects/featured` | Featured only |
| `GET` | `/api/projects/:id` | Single project |

### Contact
| Method | Endpoint | Body |
|---|---|---|
| `POST` | `/api/contact` | `{ name, email, subject, message }` |

### Health
| Method | Endpoint | |
|---|---|---|
| `GET` | `/api/health` | Server + DB status |

---

## 🚀 Deployment

### Vercel (recommended — free)
```bash
npm i -g vercel
vercel
```
Set environment variables in Vercel dashboard → Settings → Environment Variables.

> **Tip:** Vercel is serverless — use PostgreSQL (Neon.tech free tier) or MongoDB Atlas instead of SQLite for persistent storage.

### Render
1. Push to GitHub
2. New Web Service → connect repo
3. Build command: `npm install`
4. Start command: `npm start`
5. Add env vars in dashboard

### Railway
```bash
npm i -g @railway/cli
railway login
railway init
railway up
```
Railway can provision a PostgreSQL database — set `DATABASE_URL` and update `DB_TYPE=postgres`.

### Heroku
```bash
heroku create your-portfolio
heroku addons:create heroku-postgresql:mini
heroku config:set DB_TYPE=postgres
git push heroku main
```

---

## 🎨 Customization

### Update your info
Edit `frontend/index.html`:
- Name, tagline, bio (search for "Alex Rivera")
- Social links
- Contact email
- Stats numbers

### Add real projects
Either edit `backend/config/database.js` → `seedProjects()` array,  
or insert directly via the DB of your choice.

### Add your photo
Replace the SVG placeholder in the About section:
```html
<!-- In index.html, find about-placeholder and replace with: -->
<img src="assets/photo.jpg" alt="Your Name" class="about-photo" />
```

### Enable email notifications
Install nodemailer:
```bash
npm install nodemailer
```
Uncomment the email section in `backend/routes/contact.js` and set `SMTP_*` env vars.

---

## 🧪 Testing

```bash
npm test
# Runs Jest tests in backend/__tests__/
```

---

## 📝 Tech Stack

- **Frontend:** HTML5, CSS3 (custom design system), Vanilla JS (ES2020+)
- **Backend:** Node.js 18+, Express 4, Helmet, CORS
- **Database:** better-sqlite3 (default), pg, mongoose, mysql2
- **Dev:** Nodemon, Concurrently, Jest, Supertest
- **Fonts:** Syne (display), Inter (body), JetBrains Mono (code)

---

## License

MIT — use freely for your own portfolio.
